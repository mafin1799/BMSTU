getbin(bin,str)
char *str;
long int *bin;
{
	long int rez;
	int i;
	
	rez=0;
	for(i=0;i<32 && *str;i++){
		rez<<=1;
		switch(*str){
		case '0' :
			break;
		case '1' :
			rez|=1;
			break;
		case 'b' :
		case 'B' :
			rez>>=1;
			*str='\0';
			goto endbin;
		default :
			calc_error(4,str);
			break;
		}
		str++;
	}
endbin:
	if(i==32 && *str!='\0')
		calc_error(5);
		
	*bin=rez;
}

