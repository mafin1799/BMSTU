#include <math.h>
#include "names.h"
#include "code.h"

Stack stack[MAXSTACK];	/* �⥪ ��設� */

Stack *pstack;		/* 㪠��⥫� �� ���設� �⥪� */

Prog prog[MAXPROG];	/* ���ᨢ �ணࠬ�� ��設� */

Prog *pprog;		/* 㪠��⥫� �� ���� ᢮����� ������� */
Prog *pc;		/* ����稪 ������ */

code_init()
{
	pprog=prog;
	pstack=stack;
}

code(f)
Prog f;
{
	if(pprog>=&prog[MAXPROG])
		calc_error(10);
	*pprog++=f;
}

execute()
{
	for(pc=prog;*pc!=STOP;)
		(*pc++)();
}

push(d)
double d;
{
	if(pstack>=&stack[MAXSTACK])
		calc_error(8);
	*pstack++=d;
}

Stack pop()
{
	if(pstack<=stack)
		calc_error(9);
	return *--pstack;
}

mpop()
{
	if(pstack<=stack)
		calc_error(9);
	--pstack;
}

add()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1+=d2;
	push(d1);
}

sub()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1-=d2;
	push(d1);
}

mul()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1*=d2;
	push(d1);
}

div()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d2==0.)
		calc_error(1);
	d1/=d2;
	push(d1);
}

power()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1=pow(d1,d2);
	push(d1);
}

negate()
{
	Stack d;
	
	d=pop();
	d=-d;
	push(d);
}

assign()
{
	Stack d;
	Names *pn;
	
	d=pop();
	pn=(Names*)(*pc++);
	pn->val=d;
	pn->def=1;
	push(d);
}

eval()
{
	Stack d;
	Names *pn;

	pn=(Names*)(*pc++);
	if(pn->def==0)
		calc_error(7,pn->name);
		
	d=pn->val;
	push(d);
}

pushconst()
{
	Names *pn;
	
	pn=(Names*)(*pc++);
	push((Stack)(pn->val));
}

fval()
{
	Stack d;
	
	d=pop();
	d=val_fun((int)(*pc++),d);
	push(d);
}

print()
{
	Stack d;
	
	d=pop();
	printf("\t%g\n",d);
}
