#include <math.h>
#include "names.h"
#include "code.h"

Stack stack[MAXSTACK];	/* �⥪ ��設� */

Stack *pstack;		/* 㪠��⥫� �� ���設� �⥪� */

Prog prog[MAXPROG];	/* ���ᨢ �ணࠬ�� ��設� */

Prog *pprog;		/* 㪠��⥫� �� ���� ᢮����� ������� */
Prog *pc;		/* ����稪 ������ */

code_init()
{
	pprog=prog;
	pstack=stack;
}

Prog* code(f)
Prog f;
{
	Prog *oprog;
	
	oprog=pprog;
	if(pprog>=&prog[MAXPROG])
		calc_error(10);
	*pprog++=f;
	
	return oprog;
}

execute()
{
	rexecute(prog);
}

rexecute(prg)
Prog *prg;
{
	for(pc=prg;*pc!=STOP;)
		(*pc++)();
}

push(d)
double d;
{
	if(pstack>=&stack[MAXSTACK])
		calc_error(8);
	*pstack++=d;
}

Stack pop()
{
	if(pstack<=stack)
		calc_error(9);
	return *--pstack;
}

mpop()
{
	if(pstack<=stack)
		calc_error(9);
	--pstack;
}

add()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1+=d2;
	push(d1);
}

sub()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1-=d2;
	push(d1);
}

mul()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1*=d2;
	push(d1);
}

div()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d2==0.)
		calc_error(1);
	d1/=d2;
	push(d1);
}

power()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	d1=pow(d1,d2);
	push(d1);
}

negate()
{
	Stack d;
	
	d=pop();
	d=-d;
	push(d);
}

assign()
{
	Stack d;
	Names *pn;
	
	d=pop();
	pn=(Names*)(*pc++);
	pn->val=d;
	pn->def=1;
	push(d);
}

eval()
{
	Stack d;
	Names *pn;

	pn=(Names*)(*pc++);
	if(pn->def==0)
		calc_error(7,pn->name);
		
	d=pn->val;
	push(d);
}

pushconst()
{
	Names *pn;
	
	pn=(Names*)(*pc++);
	push((Stack)(pn->val));
}

fval()
{
	Stack d;
	
	d=pop();
	d=val_fun((int)(*pc++),d);
	push(d);
}

print()
{
	Stack d;
	
	d=pop();
	printf("\t%g\n",d);
}

pri()
{
	Stack d;
	
	d=pop();
	printf("\t%g",d);
}

gt()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d1>d2)
		push(1.);
	else
		push(0.);
}

ge()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d1>=d2)
		push(1.);
	else
		push(0.);
}

lt()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d1<d2)
		push(1.);
	else
		push(0.);
}

le()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d1<=d2)
		push(1.);
	else
		push(0.);
}

eq()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d1==d2)
		push(1.);
	else
		push(0.);
}

ne()
{
	Stack d1,d2;
	
	d2=pop();
	d1=pop();
	if(d1!=d2)
		push(1.);
	else
		push(0.);
}

fwhile()
{
	Stack d;
	Prog *opc;
	
	opc=pc;			/* ⥫� 横�� */
	rexecute(opc+2);	/* �᫮��� 横�� */
	d=pop();
	while(d!=0.){
		rexecute(*opc);
		rexecute(opc+2);
		d=pop();
	}
	pc=*((Prog**)opc+1);		/* ���� ������ �� 横��� */
}
